Experimental scripts that either:
* do not work
* are not fulfilling their purpose completely

Kept for archiving purposes only.